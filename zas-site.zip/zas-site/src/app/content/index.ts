import type {
  ComoFuncionaConteudo,
  DuvidasConteudo,
  EstacioneAgoraConteudo,
  Fotos,
  HomeConteudo,
  InstitucionalConteudo,
  Links,
  NaoEncontradaConteudo,
  Navegacao,
  SeoPorPagina,
  Site,
  SuporteConteudo,
  TarifasERegrasConteudo,
  Trecho,
  Ui,
} from './content.types';
import comoFuncionaJson from './como-funciona.json';
import duvidasJson from './duvidas.json';
import estacioneAgoraJson from './estacione-agora.json';
import fotosJson from './fotos.json';
import homeJson from './home.json';
import institucionalJson from './institucional.json';
import linksJson from './links.json';
import naoEncontradaJson from './nao-encontrada.json';
import navegacaoJson from './navegacao.json';
import seoJson from './seo.json';
import siteJson from './site.json';
import suporteJson from './suporte.json';
import tarifasERegrasJson from './tarifas-e-regras.json';
import uiJson from './ui.json';

export const SITE: Site = siteJson;
export const NAVEGACAO: Navegacao = navegacaoJson;
export const LINKS: Links = linksJson;
export const SEO: SeoPorPagina = seoJson;
export const UI: Ui = uiJson;

export const HOME: HomeConteudo = homeJson;
export const COMO_FUNCIONA: ComoFuncionaConteudo = comoFuncionaJson;
export const ESTACIONE_AGORA: EstacioneAgoraConteudo = estacioneAgoraJson;
export const TARIFAS_E_REGRAS: TarifasERegrasConteudo = tarifasERegrasJson;
export const DUVIDAS: DuvidasConteudo = duvidasJson;
export const SUPORTE: SuporteConteudo = suporteJson;
export const INSTITUCIONAL: InstitucionalConteudo = institucionalJson;
export const NAO_ENCONTRADA: NaoEncontradaConteudo = naoEncontradaJson;
export const FOTOS: Fotos = fotosJson;

/** Marcador de conteúdo ainda não fornecido; o build de produção falha enquanto existir. */
export function estaPendente(valor: string): boolean {
  return valor.startsWith('[PENDENTE');
}

export function textoPlano(trechos: Trecho[]): string {
  return trechos
    .map((trecho) => ('paragrafo' in trecho ? trecho.paragrafo : trecho.lista.join('; ')))
    .join(' ')
    .replaceAll('**', '');
}
