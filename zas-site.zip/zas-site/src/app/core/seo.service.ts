import { DOCUMENT, DestroyRef, Injectable, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SEO, SITE, estaPendente } from '@app/content';
import type { PaginaId } from '@app/content/content.types';
import { filter } from 'rxjs';

function isPaginaId(valor: unknown): valor is PaginaId {
  return typeof valor === 'string' && Object.hasOwn(SEO, valor);
}

@Injectable({ providedIn: 'root' })
export class SeoService {
  private readonly router = inject(Router);
  private readonly rotaRaiz = inject(ActivatedRoute);
  private readonly title = inject(Title);
  private readonly meta = inject(Meta);
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);

  iniciar(): void {
    this.router.events
      .pipe(
        filter((evento) => evento instanceof NavigationEnd),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((evento) => this.aplicar(this.paginaAtual(), evento.urlAfterRedirects));
  }

  private paginaAtual(): PaginaId | null {
    let rota = this.rotaRaiz;
    while (rota.firstChild) {
      rota = rota.firstChild;
    }
    const pagina: unknown = rota.snapshot.data['pagina'];
    return isPaginaId(pagina) ? pagina : null;
  }

  private aplicar(pagina: PaginaId | null, url: string): void {
    if (!pagina) {
      return;
    }
    const seo = SEO[pagina];
    this.title.setTitle(seo.titulo);
    this.meta.updateTag({ property: 'og:title', content: seo.titulo });
    this.meta.updateTag({ property: 'og:type', content: 'website' });
    this.meta.updateTag({ property: 'og:locale', content: 'pt_BR' });
    if (estaPendente(seo.descricao)) {
      this.meta.removeTag('name="description"');
      this.meta.removeTag('property="og:description"');
    } else {
      this.meta.updateTag({ name: 'description', content: seo.descricao });
      this.meta.updateTag({ property: 'og:description', content: seo.descricao });
    }
    this.definirCanonical(url);
  }

  private definirCanonical(url: string): void {
    // Enquanto o domínio for [PENDENTE], não publica canonical (exige URL absoluta https).
    if (!SITE.url.startsWith('https://')) {
      return;
    }
    const caminho = url.split(/[?#]/)[0];
    const href = new URL(caminho, SITE.url).toString();
    let link = this.document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) {
      link = this.document.createElement('link');
      link.setAttribute('rel', 'canonical');
      this.document.head.appendChild(link);
    }
    link.setAttribute('href', href);
  }
}
