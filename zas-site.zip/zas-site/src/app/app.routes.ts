import { inject } from '@angular/core';
import { Router, type Routes } from '@angular/router';
import type { PaginaId } from '@app/content/content.types';

function dadosDaPagina(pagina: PaginaId): { pagina: PaginaId } {
  return { pagina };
}

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('@app/pages/home/home-page').then((m) => m.HomePage),
    data: dadosDaPagina('home'),
  },
  {
    path: 'estacione-agora',
    loadComponent: () =>
      import('@app/pages/estacione-agora/estacione-agora-page').then((m) => m.EstacioneAgoraPage),
    data: dadosDaPagina('estacioneAgora'),
  },
  {
    path: 'como-funciona',
    loadComponent: () =>
      import('@app/pages/como-funciona/como-funciona-page').then((m) => m.ComoFuncionaPage),
    data: dadosDaPagina('comoFunciona'),
  },
  {
    path: 'tarifas-e-regras',
    loadComponent: () =>
      import('@app/pages/tarifas-e-regras/tarifas-e-regras-page').then((m) => m.TarifasERegrasPage),
    data: dadosDaPagina('tarifasERegras'),
  },
  {
    path: 'duvidas',
    loadComponent: () => import('@app/pages/duvidas/duvidas-page').then((m) => m.DuvidasPage),
    data: dadosDaPagina('duvidas'),
  },
  {
    path: 'suporte',
    redirectTo: () => inject(Router).createUrlTree(['/'], { fragment: 'suporte' }),
  },
  {
    path: 'institucional',
    loadComponent: () =>
      import('@app/pages/institucional/institucional-page').then((m) => m.InstitucionalPage),
    data: dadosDaPagina('institucional'),
  },
  {
    path: '**',
    loadComponent: () =>
      import('@app/pages/nao-encontrada/nao-encontrada-page').then((m) => m.NaoEncontradaPage),
    data: dadosDaPagina('naoEncontrada'),
  },
];
