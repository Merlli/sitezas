import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NAO_ENCONTRADA, UI } from '@app/content';
import { PageHeader } from '@app/shared/components/page-header/page-header';
import { HlmButton } from '@spartan-ng/helm/button';

@Component({
  selector: 'zas-nao-encontrada-page',
  imports: [PageHeader, RouterLink, HlmButton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <zas-page-header [titulo]="conteudo.titulo" ilustracao="/ilustracoes/passo-1-sinalizacao.svg">
      <div>
        <a hlmBtn size="xl" routerLink="/" class="min-h-14 px-8 text-lg">{{ ui.voltarInicio }}</a>
      </div>
    </zas-page-header>
  `,
})
export class NaoEncontradaPage {
  protected readonly conteudo = NAO_ENCONTRADA;
  protected readonly ui = UI;
}
