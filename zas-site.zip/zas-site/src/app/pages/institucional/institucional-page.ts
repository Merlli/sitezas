import { ChangeDetectionStrategy, Component } from '@angular/core';
import { INSTITUCIONAL, estaPendente } from '@app/content';
import { PageHeader } from '@app/shared/components/page-header/page-header';

@Component({
  selector: 'zas-institucional-page',
  imports: [PageHeader],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <zas-page-header [titulo]="conteudo.titulo" />
    <div class="mx-auto max-w-6xl px-4 py-12 sm:py-16">
      <div
        class="flex flex-col gap-6 rounded-[2rem] border border-border bg-white p-6 shadow-[0_20px_50px_-34px_rgb(0_48_87/0.45)] sm:p-10"
      >
        <img
          src="/marca/zas-logo-sindguarda.webp"
          alt=""
          width="400"
          height="159"
          class="h-auto w-40 sm:w-48"
        />
        @for (paragrafo of conteudo.paragrafos; track $index) {
          <p
            class="max-w-prose text-base leading-relaxed text-zas-marinho/85 sm:text-lg"
            [class]="pendente(paragrafo) ? 'rounded-2xl border-2 border-dashed border-zas-bruma p-4' : ''"
          >
            {{ paragrafo }}
          </p>
        }
      </div>
    </div>
  `,
})
export class InstitucionalPage {
  protected readonly conteudo = INSTITUCIONAL;
  protected readonly pendente = estaPendente;
}
